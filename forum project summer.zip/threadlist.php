<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>idiscuss</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
    <?php  include '_dbconnect.php';?>
<?php include 'header.php';?>
</body>
<!----- first page of website No thread found wala ---->
<?php
  //dynamically change the name and descripton
$id=$_GET['catid'];
$sql="SELECT * FROM project WHERE catagery_id='$id'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result))
      {
        $catname=$row['catagery_name'];
        $catdesc=$row['catagery_description'];

      }
      ?>
<!---idiscuss catogries  container start here ---->
<!---primary ki jaga per success kerne sai color green hojata learn more button below ---->
<!---  echo $catname  is used to change NAME DYNAMICALLY IF USER CLICK TO IT AND echo $catdesc change DESCRIPTION DYNAMICALLY IF USER CLICK TO IT    ---->
<div class="container my-4">
    <div class="jumbotron">
        <h1 class="display-4">Welcome to
            <?php
         echo $catname; 
         ?>
            forms</h1>
        <p class="lead"><?php echo $catdesc?></p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <a class="btn btn-success btn-lg" href="#" role="button">Learn more</a>
    </div>
</div>
<?php
   if(isset($_SESSION['loggedin'])&&$_SESSION['loggedin']==True)
   {
echo '<div class="container">
    <h3 class="text-center my-5">iDiscuss Browse Question</h3>
        <h3>Lets Start Disscusion!!!</h3>
        <form action="'. $_SERVER["REQUEST_URI"].'" method="POST">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" aria-describedby="emailHelp">
            </div>
            <input type="hidden" name="sno" value="'. $_SESSION['sno']. '">
            <div class="form-group">
                <label for="form-control">Description</label>
                <textarea class="form-control" id="desc" name="desc" rows="3"></textarea>
            </div>
            <br>
            <button type="submit" class="btn btn-success">Post Comment</button>
    </form>
    </div>';
   }
   else
   {
    echo '<div class="container">
    <p>You are not logged in you should have to login your account Please login to Start a Disscussion</p><a href="login_demo2.php">Login here</a>
  </div>';
   }

   ?>

<div class="container my-3">
<?php
  //dynamically change the name and descripton
$id=$_GET['catid'];
$sql="SELECT * FROM threads WHERE thread_catagery_id='$id'";
$result=mysqli_query($conn,$sql);
$noresult=true;
while($row=mysqli_fetch_assoc($result))
      {
        $noresult=false;
        $thid=$row['thread_id'];
        $thtitle=$row['thread_title'];
        $thdesc=$row['thread_desc'];
        $currenttime=$row['createdtime'];
        $thread_user_id=$row['thread_user_id'];
        $sql2="SELECT email FROM `uk` WHERE sno='$thread_user_id'";
        $result2=mysqli_query($conn,$sql2);
        $row2=mysqli_fetch_assoc($result2);

    echo '<div class="media">
        <img src="\forumproject\forums\uk-1.PNG" width="40px" class="mr-3" alt="...">
        <div class="media-body">
        <p class="fw-bold my-0">'.$row2['email'].' at '.$currenttime.'</p>
            <h5 class="mt-0"><a href="thread.php?threadid='.$thid.'">'.$thtitle.'</h5></a>
            '.$thdesc.'
        </div>
    </div>';
      }
      if($noresult)
      {
        echo '<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h4 class="display-8">No threaad found</h4>
    <p class="lead">Be the first Person to Ask question</p>
  </div>
</div>';
      }
      
?>
<?php
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $th_title=$_POST['title'];
    $th_desc=$_POST['desc'];
    $sno = $_POST['sno']; 
    $th_title = str_replace("<", "&lt;", $th_title);
        $th_title = str_replace(">", "&gt;", $th_title); 

        $th_desc = str_replace("<", "&lt;", $th_desc);
        $th_desc = str_replace(">", "&gt;", $th_desc); 

    $sql="INSERT INTO `threads` ( `thread_title`, `thread_desc`, `thread_user_id`, `thread_catagery_id`, `createdtime`) VALUES 
    ( '$th_title', '$th_desc', '$sno', '$id' ,current_timestamp())";
     $result=mysqli_query($conn,$sql);
//check table create succesfully
if($result)
{
 
}
else
{
    echo"sorry not successfully<br>".mysqli_error($conn);
}
}


?>
</div>
<!---
<div class="container my-3">
    <div class="media">
        <img src="\forumproject\forums\uk-1.PNG" width="40px" class="mr-3" alt="...">
        <div class="media-body">
            <h5 class="mt-0">Username</h5>
            Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio,
            vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec
            lacinia congue felis in faucibus.
        </div>
    </div>
    </div> ---->

</html>