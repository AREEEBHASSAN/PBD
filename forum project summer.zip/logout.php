<?php
session_start();
echo "looged out please wait-----! ";
session_destroy();
header("location:/forumproject/forums");

?>