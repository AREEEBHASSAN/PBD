<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bootstrap Simple Login Form with Blue Background</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<style>
	body {
		color: #fff;
        background-image: url("photoforwebsite.jpg");
	}
	.form-control {
		min-height: 60px;
		background:  #FFFFFF;
		box-shadow: none !important;
		border: transparent;
	}
	.form-control:focus {
		background: #FFFDD0;
	}
	.form-control, .btn {        
        border-radius: 2px;
    }
	.login-form {
		width: 400px;
		margin: 30px auto;
		text-align: center;
	}
	.login-form h2 {
        margin: 10px 0 25px;
    }
    .login-form form {
		color: #00FF00 ;
		border-radius: 3px;
    	margin-bottom: 15px;
        background: #000000;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form .btn {        
        font-size: 16px;
        font-weight: bold;
		background:  #00FF00;
		border: none;
        outline: none !important;
    }
	.login-form .btn:hover, .login-form .btn:focus {
		background: #00FF00;
	}
	.login-form a {
		color:#00FF00 ;
		text-decoration: underline;
	}
	.login-form a:hover {
		text-decoration: none;
	}
	.login-form form a {
		color:#FFFFFF ;
		text-decoration: none;
	}
	.login-form form a:hover {
		text-decoration: underline;
	}
</style>
</head>
<body>
<div class="login-form">
<form action="/forumproject/forums/login_demo2.php"method="POST">
        <h2 class="text-center">Login</h2>   
        <div class="form-group has-error">
        	<input type="text" class="form-control" name="email" placeholder="User_Email" required="required">
        </div>
		<div class="form-group">
            <input type="password" class="form-control" name="pass"  required="required">
        </div>        
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg btn-block">Sign in</button>
        </div>
        <p><a href="#">Lost your Password?</a></p>
    </form>
    <p class="text-center small ">Don't have an account? <a href="sinup_demo2.php">Sign up here!</a></p>
</div>
<?php
if($_SERVER['REQUEST_METHOD']=="POST")
{
  include '_dbconnect.php';
  $showalert=false;
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $existsql="SELECT *from uk where email='$email'";
    $result=mysqli_query($conn,$existsql);;
    $existsrow=mysqli_num_rows($result);
    if($existsrow==1)
    {
     $row=mysqli_fetch_assoc($result);
     if(password_verify($pass,$row['password'])){
        session_start();
        $_SESSION['loggedin']=true;
        $_SESSION['sno'] = $row['sno'];
        $_SESSION['useremail']=$email;
     }
     header("location:/forumproject/forums/index.php");
    }


}
?>
</body>
</html>