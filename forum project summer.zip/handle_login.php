<?php
/*
if($_SERVER['REQUEST_METHOD']=="POST")
{
  include '_dbconnect.php';
  $showalert=false;
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $existsql="SELECT *from uk where email='$email'";
    $result=mysqli_query($conn,$existsql);;
    $existsrow=mysqli_num_rows($result);
    if($existsrow==1)
    {
     $row=mysqli_fetch_assoc($result);
     if(password_verify($pass,$row['password'])){
        session_start();
        $_SESSION['loggedin']=true;
        $_SESSION['useremail']=$email;
        echo "logged in".$email;
        header("location:/forumproject/forums/index.php");
     }
     else
     {
        echo'<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Unable to logged in!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
     }
    }
    


}
*/
?>