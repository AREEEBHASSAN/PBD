
<?php
session_start();
echo'<nav class="navbar navbar-expand-sm sticky-top navbar-light bg-light">
<div class="container-fluid">
  <a class="navbar-brand" href="/forumproject/forums">Idis</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="/forumproject/forums">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="aboutus.php">About</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Catogries
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="#">Phython</a>
        <a class="dropdown-item" href="#">JavaScript</a>
        <a class="dropdown-item" href="#">Flask</a>
        <a class="dropdown-item" href="#">DJanGo</a>

          
      </div>
      </li>
      <li class="nav-item">
        <a class="nav-link"href="contactus.php">Contact Us</a>
      </li>
    </ul>';
    if(isset($_SESSION['loggedin'])&&$_SESSION['loggedin']==True)
    {
    echo '<form class="d-flex" role="search">
    welcome '.$_SESSION['useremail'].'
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
      <a href="logout.php"class="btn btn-outline-success data-bs-toggle="modal" data-bs-target="loginmodal">logout</a>
      
    </form>';
    
    }
    else
    {
      echo '<form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    <ul class="navbar-nav">
    <a href="login_demo2.php"class="btn btn-outline-success data-bs-toggle="modal" data-bs-target="loginmodal">login</a>
      <li class="nav-item">
      <a href="sinup_demo2.php"class="btn btn-outline-success data-bs-toggle="modal" data-bs-target="#sinupmodal">sinup</a>
      </li>';
    }
 echo  '</div>
</div>
</nav>';
?>

<!---- sql to get catageries dynamacally
 $sql="SELECT catagery_name,catagery_id FROM `project`;";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result))
{
  echo '<a class="dropdown-item" href="threadlist.php?catid='.$row['catagery_id'].'">'.$row['catagery_name'].'</a>';
}
--->

